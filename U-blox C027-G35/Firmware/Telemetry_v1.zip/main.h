#ifndef MAIN_H
#define MAIN_H

#include "C027.h"
#include "GPS.h"
#include "MDM.h"

// Set your secret SIM pin here (e.g. "1234")
#define SIMPIN   NULL
// Internet parameters
#define APN         "internet.wind"
#define USERNAME    NULL
#define PASSWORD    NULL

// CAN protocol
#define CAN_FREQUENCY     250000
#define CAN_ID_DATETIME   0x51
#define CAN_ID_LATITUDE   0x52
#define CAN_ID_LONGITUDE  0x53

#define CAN_ID_HMI         0x11
#define CAN_ID_ACTUATION1  0x21
#define CAN_ID_ACTUATION2  0x22
#define CAN_ID_SENSOR1     0x31
#define CAN_ID_SENSOR2     0x32
#define CAN_ID_SAFEBOARD   0x41

// GSM protocol
#define TERMINATION_CHAR  255
#define ESCAPE_CHAR       254
#define TELEMETRY_TYPE    1
#define GPS_TYPE          2

typedef struct {
    uint8_t lat_degree;
    uint8_t lat_minutes;
    double lat_seconds;
    uint8_t lon_degree;
    uint8_t lon_minutes;
    double lon_seconds;
} GPSMessage;

typedef struct {
    uint16_t minutes;
    uint16_t seconds_cent;
    uint16_t voltage;
    uint16_t auxVoltage;
    uint16_t current;
    uint16_t speed;
    uint16_t temperature1;
    uint16_t temperature2;
    uint16_t temperature3;
    uint16_t humidity1;
    uint16_t humidity2;
    uint16_t strategy;
    uint16_t button_status;
    uint8_t actuation;
    uint8_t electricMotor;
    uint8_t emergency;
    uint8_t RPMEM;
    uint8_t RPMICE;
    uint8_t cruiseControl;
} TelemetryMessage;

#endif