#include "mbed.h"
#ifndef TARGET_UBLOX_C027
#error "This example is targeted for the C027 platform"
#endif

#include "HTTPClient.h"
#include "main.h"

// Hardware interfaces
C027 c027;
Serial pcSerial(USBTX, USBRX);
CAN can0(CANRD, CANTD);
DigitalOut canEn(CANS, 1); // pin to enable the can interface
DigitalOut myled0(LED, 0);

// Functions
void can_recive_manage(); // Interrupt to manage recived message from can bus
void error_led(bool error);

// Global variables
volatile GPSMessage gps_message;
volatile TelemetryMessage telemetry_message;
char canData[8];
int len;
char buffer[2048];

extern "C" void SysTick_Handler (void) {
    telemetry_message.seconds_cent++;
    if(telemetry_message.seconds_cent >= 6000){
        telemetry_message.minutes++;
        telemetry_message.seconds_cent = 0;
    }
}

int main()
{
    telemetry_message.minutes = 0;
    telemetry_message.seconds_cent = 0;
    SysTick_Config(SystemCoreClock / 100);
    // PC communication init
    pcSerial.baud(115200);
    pcSerial.printf("Init:\r\n");
    // GPS init
    pcSerial.printf("GPS...");
    GPSI2C gps(GPSSDA,GPSSCL,GPSADR);
    pcSerial.printf("ON\r\n");
    // MDM init (MDM = MobileDeviceManager)
    pcSerial.printf("MDM...");
    MDMParser::DevStatus deviceStatus = {};
    MDMParser::NetStatus netStatus = {};
    MDMSerial mdmSerial(MDMTXD, MDMRXD, MDMBAUD, MDMRTS, MDMCTS, 256, 128);
    bool mdmStatus = mdmSerial.init(SIMPIN, &deviceStatus);
    mdmSerial.dumpDevStatus(&deviceStatus);
    error_led(!mdmStatus);
    mdmStatus = mdmSerial.registerNet(&netStatus);
    error_led(!mdmStatus);
    mdmSerial.dumpNetStatus(&netStatus);
    // join to internet connection
    MDMParser::IP myIP = mdmSerial.join(APN, USERNAME, PASSWORD);
    mdmSerial.dumpIp(myIP);
    error_led(myIP == NOIP);
    pcSerial.printf("ON\r\n");
    // CAN init
    pcSerial.printf("CAN BUS...");
    can0.frequency(CAN_FREQUENCY);
    can0.mode(CAN::Normal);
    canEn = 0; // enable the can interface
    can0.attach(&can_recive_manage);  // function that manage recived messages
    pcSerial.printf("ON\r\n");

    pcSerial.printf("Start loop:\r\n");
    myled0 = 1;
    while(1) {

        // -------------------- GPS --------------------
        len = gps.getMessage(buffer, sizeof(buffer));
        len = LENGTH(len); // length conversion
        //pcSerial.printf(buffer); // debug
        // Get date and time
        if(strstr(buffer, "$GPRMC")) {
            int time, date;
            if(gps.getNmeaItem(1, buffer, len, time, 10) &&
                    gps.getNmeaItem(9, buffer, len, date, 10)) {
                // date and time correctly read
                // time format = hhmmss
                // date format = ddmmyy
                canData[2] = date / 10000; // day
                date -= canData[2] * 10000;
                canData[1] = date / 100; // month
                date -= canData[1] * 100;
                canData[0] = date; // year

                canData[5] = date / 10000; // seconds
                date -= canData[2] * 10000;
                canData[4] = date / 100; // minutes
                date -= canData[1] * 100;
                canData[3] = date; // hours

                can0.write(CANMessage(CAN_ID_DATETIME, canData, 6));

                //telemetry_message.minutes = canData[4];
            }
        }
        // Get latitude and longitude
        if(strstr(buffer, "$GPGGA")) {
            double latitude, longitude, time, altitude;
            int satellites;
            char direction[2];

            if(gps.getNmeaItem(2, buffer, len, latitude) &&
                    gps.getNmeaItem(4, buffer, len, longitude) &&
                    gps.getNmeaItem(3, buffer, len, direction[0]) &&
                    gps.getNmeaItem(5, buffer, len, direction[1]) &&
                    gps.getNmeaItem(1, buffer, len, time) &&
                    gps.getNmeaItem(9, buffer, len, altitude) &&
                    gps.getNmeaItem(7, buffer, len, satellites, 10)) {
                // latitude and longitude correctly read
                // latitude  format =  ddmm.mmmmm
                // longitude format = dddmm.mmmmm
                canData[0] = ((int) latitude) / 100; // lat_degrees
                latitude -= canData[0] * 100;
                gps_message.lat_degree = canData[0];
                gps_message.lat_minutes = latitude;
                gps_message.lat_seconds = (latitude - gps_message.lat_minutes)*60;
                latitude *= 100000;
                canData[1] = ((int) latitude) >> 16;
                canData[2] = (((int) latitude) >> 8) & 0xFF;
                canData[3] = ((int) latitude) & 0xFF;
                canData[4] = (direction[0] == 'N')? 0 : 1;
                altitude *= 100;
                canData[5] = ((int) altitude) >> 8;
                canData[6] = ((int) altitude) & 0xFF;

                can0.write(CANMessage(CAN_ID_LATITUDE, canData, 7));

                canData[0] = ((int) longitude) / 100; // lon_degrees
                longitude -= canData[0] * 100;
                gps_message.lon_degree = canData[0];
                gps_message.lon_minutes = longitude;
                gps_message.lon_seconds = (longitude - gps_message.lon_minutes)*60;
                longitude *= 100000;
                canData[1] = ((int) longitude) >> 16;
                canData[2] = (((int) longitude) >> 8) & 0xFF;
                canData[3] = ((int) longitude) & 0xFF;
                canData[4] = (direction[1] == 'E')? 0 : 1;
                // time format = hhmmss.ss
                canData[5] = (time - ((int) time)) * 100;
                canData[6] = satellites;

                can0.write(CANMessage(CAN_ID_LONGITUDE, canData, 7));
                //telemetry_message.seconds_cent = (time - ((int)(time/100))*100)*100;
            }
        }

        // -------------------- MDM --------------------
        
        int socket = mdmSerial.socketSocket(MDMParser::IPPROTO_TCP);
        mdmSerial.socketSetBlocking(socket, 10000); // timeout
        pcSerial.printf("CONNECT SOCKET...");
        if (mdmSerial.socketConnect(socket, "88.198.45.20", 80)) {
            pcSerial.printf("OK\r\n");
            // pipelined
            //sprintf(buffer, "GET /index.php/databaseio/insertAll?minutes=%d&seconds100=%d&voltage=%d&current=%d&speed=%d&temperature1=%d&temperature2=%d&temperature3=%d&humidity1=%d&humidity2=%d&strategy=%d&actuation=%d&electricMotor=%d&emergency=%d&RPMEM=%d&RPMICE=%d&cruiseControl=%d&auxVoltage=%d HTTP/1.1\r\nHost: telemetryh2polito.altervista.org\r\nConnection: Keep-Alive\r\n\r\nGET /index.php/databaseio/insertTelemetria?voltage=1&current=2&speed=3&race_id=0 HTTP/1.1\r\nHost: telemetryh2polito.altervista.org\r\n\r\nConnection: close\r\n\r\n",
            // not pipelined
            sprintf(buffer, "GET /index.php/databaseio/insertAll?minutes=%d&seconds100=%d&voltage=%f&auxVoltage=%f&current=%f&speed=%f&temperature1=%f&temperature2=%f&temperature3=%f&humidity1=%f&humidity2=%f&strategy=%d&actuation=%d&electricMotor=%d&emergency=%d&RPMEM=%d&RPMICE=%d&cruiseControl=%d&lat_deg=%d&lat_min=%d&lat_sec=%f&long_deg=%d&long_min=%d&long_sec=%f&id_gara=0 HTTP/1.1\r\nHost: telemetryh2polito.altervista.org\r\n\r\n",
            telemetry_message.minutes,
            telemetry_message.seconds_cent,
            telemetry_message.voltage/100.0,
            telemetry_message.auxVoltage/100.0,
            telemetry_message.current/100.0,
            telemetry_message.speed/100.0,
            telemetry_message.temperature1/100.0,
            telemetry_message.temperature2/100.0,
            telemetry_message.temperature3/100.0,
            telemetry_message.humidity1/100.0,
            telemetry_message.humidity2/100.0,
            telemetry_message.strategy,
            telemetry_message.actuation,
            telemetry_message.electricMotor,
            telemetry_message.emergency,
            telemetry_message.RPMEM,
            telemetry_message.RPMICE,
            telemetry_message.cruiseControl,
            gps_message.lat_degree,
            gps_message.lat_minutes,
            gps_message.lat_seconds,
            gps_message.lon_degree,
            gps_message.lon_minutes,
            gps_message.lon_seconds);
            pcSerial.printf("SEND REQUEST...");
            mdmSerial.socketSend(socket, buffer, sizeof(buffer)-1);
            pcSerial.printf("OK\r\n");
            //pcSerial.printf("RECIVE DATA...");
            //int ret = mdmSerial.socketRecv(socket, buffer, sizeof(buffer)-1);
            //pcSerial.printf("OK\r\n");
            
            //if (ret > 0)
                //pcSerial.printf("Socket Recv \"%*s\"\r\n", ret, buffer);
            pcSerial.printf("CLOSE SOCKET...");
            mdmSerial.socketClose(socket);
            pcSerial.printf("OK\r\n");
        }
        pcSerial.printf("DESTROY SOCKET...");
        mdmSerial.socketFree(socket);
        pcSerial.printf("OK\r\n");
        pcSerial.printf("------------------------------\r\n");

    }
}

// Interrupt to manage recived message from can bus
void can_recive_manage()
{
    CANMessage canMsg;
    if (can0.read(canMsg)) {
        myled0 = !myled0; // led blink for debug
        switch (canMsg.id) {
            case CAN_ID_HMI:
                telemetry_message.strategy = canMsg.data[0];
                telemetry_message.button_status = canMsg.data[1];
                telemetry_message.actuation = (canMsg.data[1] >> 3) & 0x01;
                telemetry_message.electricMotor = (canMsg.data[1] >> 2) & 0x01;
                break;
            case CAN_ID_ACTUATION1:
                telemetry_message.voltage = canMsg.data[0]*256 + canMsg.data[1];
                telemetry_message.current = canMsg.data[2]*256 + canMsg.data[3];
                telemetry_message.speed = canMsg.data[6]*256 + canMsg.data[7];
                break;
            case CAN_ID_ACTUATION2:
                break;
            case CAN_ID_SENSOR1:
                telemetry_message.temperature1 = canMsg.data[0]*256 + canMsg.data[1];
                telemetry_message.temperature2 = canMsg.data[2]*256 + canMsg.data[3];
                telemetry_message.temperature3 = canMsg.data[4]*256 + canMsg.data[5];
                break;
            case CAN_ID_SENSOR2:
                telemetry_message.humidity1 = canMsg.data[4]*256 + canMsg.data[5];
                telemetry_message.humidity2 = canMsg.data[6]*256 + canMsg.data[7];
                break;
            case CAN_ID_SAFEBOARD:
                telemetry_message.emergency = canMsg.data[3];
                break;
        }
    }
}

void error_led(bool error)
{
    if(error == true) {
        pcSerial.printf("FAIL\r\n");
        while(1) {
            myled0 = !myled0;
            wait(1);
        }
    }
}