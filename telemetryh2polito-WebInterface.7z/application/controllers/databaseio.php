<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Databaseio extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('model_databaseio');
	}

	public function insertTelemetria(){
    $data = array();
    if($this->input->get('tensione') != ''){
			$data['tensione'] = $this->input->get('tensione');
    }else{
      echo "<p>Tensione non inserita, di default verr� impostata a zero.</p>";
      $data['tensione'] = 0;
    }
    
    if($this->input->get('corrente') != ''){
			$data['corrente'] = $this->input->get('corrente');
    }else{
      echo "<p>Corrente non inserita, di default verr� impostata a zero.</p>";
      $data['corrente'] =  0;
    }
    
    if($this->input->get('velocita') != ''){
			$data['velocita'] = $this->input->get('velocita');
    }else{
      echo "<p>Velocit� non inserita, di default verr� impostata a zero.</p>";
      $data['velocita'] = 0;
    }
    
    if($this->input->get('id_gara') != ''){
			$data['id_gara'] = $this->input->get('id_gara');
    }else{
      echo "<p>Id gara non inserito, di default verr� impostata a zero.</p>";
      $data['id_gara'] = 0;
    }
    
    $this->model_databaseio->insertTelemetria($data);
    
    echo "<p><strong>Done</strong></p>";
	}
  
  public function insertGps(){
    $data = array();
    if($this->input->get('lat_deg') != ''){
			$data['lat_deg'] = $this->input->get('lat_deg');
    }else{
      echo "<p>Gradi latitudine non inseriti.</p>";
      return;
    }
    
    if($this->input->get('lat_min') != ''){
			$data['lat_min'] = $this->input->get('lat_min');
    }else{
      echo "<p>Minuti latitudine non inseriti.</p>";
      return;
    }
    
    if($this->input->get('lat_sec') != ''){
			$data['lat_sec'] = $this->input->get('lat_sec');
    }else{
      echo "<p>Secondi latitudine non inseriti.</p>";
      return;
    }
    
    if($this->input->get('long_deg') != ''){
			$data['long_deg'] = $this->input->get('long_deg');
    }else{
      echo "<p>Gradi longitudine non inseriti.</p>";
      return;
    }
    
    if($this->input->get('long_min') != ''){
			$data['long_min'] = $this->input->get('long_min');
    }else{
      echo "<p>Minuti longitudine non inseriti.</p>";
      return;
    }
    
    if($this->input->get('long_sec') != ''){
			$data['long_sec'] = $this->input->get('long_sec');
    }else{
      echo "<p>Secondi longitudine non inseriti.</p>";
      return;
    }
    
    $this->model_databaseio->insertGps($data);
    
    echo "<p><strong>Done</strong></p>";
	}
  
  public function getTelemetria($setLetto = 1){
    $result = array();
    if($this->input->get('id_gara') != ''){
			$result = $this->model_databaseio->getTelemetria($this->input->get('id_gara'), $setLetto);
    }else{
      $result = $this->model_databaseio->getTelemetria(-1, $setLetto);
    }
    echo json_encode($result);
	}
  
  public function getGps($setLetto = 1){
    $result = array();
    if($this->input->get('id_gara') != ''){
			$result = $this->model_databaseio->getGps($this->input->get('id_gara'), $setLetto);
    }else{
      $result = $this->model_databaseio->getGps(-1, $setLetto);
    }
    echo json_encode($result);
	}
}

/* End of file databaseio.php */
/* Location: ./application/controllers/databaseio.php */