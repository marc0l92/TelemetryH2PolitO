	</div> <!-- col-lg-9  -->
</div><!--  row       -->
</div> <!-- container -->
<!--div id="footer" class="row hidden-print">
	<div class="col-lg-12">
		<span><strong>Telemetry H2politO</strong></span>
	</div>
</div-->
</body>
</html>